I am an abstract class defining the basic behaviour and state to execute a task:
  - the basic executeTask: method
  - an exception handler meant to manage unhandled exception