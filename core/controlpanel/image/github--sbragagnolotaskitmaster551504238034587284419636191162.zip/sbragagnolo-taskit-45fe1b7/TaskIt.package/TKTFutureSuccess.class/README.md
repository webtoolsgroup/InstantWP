I represent a the result of a success task.

I ignore failure callbacks and schedule for execution success callbacks