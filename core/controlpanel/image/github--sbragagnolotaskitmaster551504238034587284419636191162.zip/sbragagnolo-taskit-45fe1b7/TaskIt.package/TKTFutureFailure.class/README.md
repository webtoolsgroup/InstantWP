I represent a the result of a failured task.

I ignore success callbacks and schedule for execution failure callbacks