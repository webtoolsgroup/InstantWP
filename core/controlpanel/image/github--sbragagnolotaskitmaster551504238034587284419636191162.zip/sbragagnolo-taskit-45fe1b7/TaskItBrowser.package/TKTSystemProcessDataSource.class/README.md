This data source allows to watch system processes into the TaskIT browser. 
Since they are not yet reified as TaskIT tasks / jobs, they do not have extra data nor events.