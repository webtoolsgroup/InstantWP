This announcement tells that the process has been stopped from other thread, meaning that it was really cancelled and not just cancelled by it self as a way to stop. 

In this case the announcement has the process reference and the suspended context where the thread was stopped.