The class variables of this class was manually extracted from: 
http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/fcntl.h.html